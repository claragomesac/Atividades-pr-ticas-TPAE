import java.util.Scanner;
public class Mymetodos{
    public static void main(String[]args) {
        Scanner entrada = new Scanner (System.in);
        int preco;
        int codigo;
        int compra;
        int desconto;
        int quantidade;
        int bruto;

        System.out.print ("Digite o código do produto");
        codigo = entrada.nextInt(); 
        System.out.print ("Digite a quantidade de produtos");
        quantidade = entrada.nextInt();

        if (codigo <= 10) {
            preco = 10; 
        } else if (codigo <= 20) {
            preco = 15;
        } else if (codigo <= 30) {
            preco = 20;
        } else {
            preco = 30;
        }
        bruto = preco * quantidade;

        if (bruto <= 250) {
            desconto = (preco*5)/bruto;
        } else if (bruto <= 500) {
            desconto = (preco*10)/bruto;
        } else {
            desconto = (preco*15)/bruto;
        }

        compra = bruto - desconto;

        System.out.printf("O preco do produto e %d/n", preco);
        System.out.printf("O valor bruto do produto e %d/n", bruto);
        System.out.printf("O desconto obtido e %d/n", desconto);
        System.out.printf("O valor final do produto e %d/n", compra);

        entrada.close();
    }
}
