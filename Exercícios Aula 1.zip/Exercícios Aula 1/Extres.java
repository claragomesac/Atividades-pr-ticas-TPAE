import java.util.Scanner;
public class Extres{
    public static void main(String[]args) {
        Scanner entrada = new Scanner (System.in);
        int quantidade=0;
        int vogais=0;
        String frase; 
        String[] v;
        v = frase.split("");

        System.out.print("Digite a quantidade de palavras");
        System.out.println(frase);

        for(int i=0; i<quantidade; i++){
            char c = frase.char(i);
            if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u'){
                vogais++;
            }
            return vogais;
    }   
        entrada.close();
    }
}