import java.util.Scanner;
public class Sig {
    private Disciplina disciplina;
    private Scanner scanner;

    public Sig() {
        disciplina = null;
        scanner = new Scanner(System.in);
    }

    public void executar() {
        int opcao;
        do {
            exibirMenu();
            opcao = lerOpcao();
            executarOpcao(opcao);
        } while (opcao != 4);
    }

    private void exibirMenu() {
        System.out.println("### MENU ###");
        System.out.println("1. Cadastrar disciplina");
        System.out.println("2. Cadastrar dados de aluno em disciplina");
        System.out.println("3. Mostrar diario de disciplina");
        System.out.println("4. Sair");
        System.out.print("Escolha uma opcao: ");
    }

    private int lerOpcao() {
        return scanner.nextInt();
    }

    private void executarOpcao(int opcao) {
        switch (opcao) {
            case 1:
                cadastrarDisciplina();
                break;
            case 2:
                cadastrarAluno();
                break;
            case 3:
                mostrarDiario();
                break;
            case 4:
                System.out.println("Saindo do sistema...");
                break;
            default:
                System.out.println("Opcao invalida.");
        }
    }

    private void cadastrarDisciplina() {
        scanner.nextLine(); // Limpar o buffer do scanner
        System.out.print("Digite o codigo da disciplina: ");
        String codigo = scanner.nextLine();
        disciplina = new Disciplina(codigo);
        System.out.println("Disciplina cadastrada com sucesso.");
    }

    private void cadastrarAluno() {
        if (disciplina == null) {
            System.out.println("Nenhuma disciplina cadastrada. Cadastre uma disciplina primeiro.");
            return;
        }
        scanner.nextLine(); // Limpar o buffer do scanner
        System.out.print("Digite o nome do aluno: ");
        String nome = scanner.nextLine();
        System.out.print("Digite a nota do aluno: ");
        int nota = scanner.nextInt();
        System.out.print("Digite a quantidade de faltas do aluno: ");
        int faltas = scanner.nextInt();
        Aluno aluno = new Aluno(nome, nota, faltas);
        disciplina.adicionarAluno(aluno);
        System.out.println("Aluno cadastrado com sucesso.");
    }

    private void mostrarDiario() {
        if (disciplina == null) {
            System.out.println("Nenhuma disciplina cadastrada. Cadastre uma disciplina primeiro.");
            return;
        }
        disciplina.ordenarDiario();
        System.out.println("\nDisciplina: " + disciplina.getCodigo());
        System.out.printf("%-10s %-12s %-8s %-10s %n", "Nome", "Nota", "Faltas", "Situacao");
        for (Aluno aluno : disciplina.getListaAlunos()) {
            System.out.printf("%-10s %-12s %-8s %-10s %n", aluno.getNome(), aluno.getNota(), aluno.getFaltas(),
                    aluno.getSituacao());
        }
    }
}
