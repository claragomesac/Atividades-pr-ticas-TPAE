import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Disciplina {
    private String codigo;
    private ArrayList<Aluno> listaAlunos;

    public Disciplina(String codigo) {
        this.codigo = codigo;
        this.listaAlunos = new ArrayList<>();
    }

    public String getCodigo() {
        return codigo;
    }

    public List<Aluno> getListaAlunos() {
        return Collections.unmodifiableList(listaAlunos);
    }

    public void adicionarAluno(Aluno aluno) {
        listaAlunos.add(aluno);
    }

    public void ordenarDiario() {
        listaAlunos.sort(getComparador());
    }

    private Comparator<Aluno> getComparador() {
        return new Comparator<Aluno>() {
            @Override 
            public int compare(Aluno aluno1, Aluno aluno2) {
                if (aluno1.getNota() != aluno2.getNota()) {
                    return aluno2.getNota() - aluno1.getNota();
                } else {
                    return aluno1.getNome().compareTo(aluno2.getNome());
                }
            }
        };
    }
}

