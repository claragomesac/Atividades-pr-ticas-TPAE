package com.mycompany.exercicio5;

import java.util.ArrayList;
import java.util.Comparator;

public class Disciplina {

    private String codigo;
    private ArrayList<Aluno> listaAlunos;

    public Disciplina(String codigo) {
        this.codigo = codigo;
        this.listaAlunos = new ArrayList<Aluno>();
    }
    
    public String getCodigo(){
        return codigo;
    }
    public void adicionarAluno(Aluno aluno) {
        listaAlunos.add(aluno);
    }

    public void ordenarDiario() {
        listaAlunos.sort(getComparator());
    }

    private Comparator<Aluno> getComparator() {
        return new Comparator<Aluno>() {
            @Override
            public int compare(Aluno aluno1, Aluno aluno2) {
                if (aluno1.getNota() != aluno2.getNota()) {
                    return aluno2.getNota() - aluno1.getNota();
                } else {
                    return aluno2.getNome().compareTo(aluno1.getNome());
                }
            }
        };
    }
    public ArrayList<Aluno> getListaAlunos(){
        return listaAlunos;
    }
}
