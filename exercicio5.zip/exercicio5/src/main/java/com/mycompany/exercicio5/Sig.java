package com.mycompany.exercicio5;

import java.util.Scanner;

public class Sig {

    private Disciplina disciplina;

    private void menu() {
        System.out.println("### MENU ###");
        System.out.println("1. Cadastrar disciplina");
        System.out.println("2. Cadastrar dados de aluno em disciplina");
        System.out.println("3. Mostrar diario de disciplina");
        System.out.println("4. Sair");
        System.out.println("Escolha uma opcao:");
    }

    public void executar() {
        menu();
        int opcao;
        Scanner in = new Scanner(System.in);
        opcao = in.nextInt();
        while (opcao != 4) {
            executarOpcao(opcao);
            menu();
            opcao = in.nextInt();
        }
    }

    public void executarOpcao(int opcao) {
        switch (opcao) {
            case 1:
                cadastrarDisciplina();
                break;
            case 2:
                cadastrarAlunos();
                break;
            case 3:
                mostrarDiario();
                break;
            default:
                break;
        }
    }

    public void cadastrarDisciplina() {
        System.out.println("Digite o codigo da disciplina:");
        Scanner in = new Scanner(System.in);
        String codigo = in.nextLine();
        disciplina = new Disciplina(codigo);
    }

    private void cadastrarAlunos() {
        System.out.println("Digite o nome do aluno:");
        Scanner in = new Scanner(System.in);
        String nomeAluno = in.nextLine();
        System.out.println("Digite a nota do aluno:");
        int notaAluno = in.nextInt();
        System.out.println("Digite as faltas do aluno:");
        int faltasAluno = in.nextInt();
        Aluno aluno = new Aluno(nomeAluno, notaAluno, faltasAluno);
        disciplina.adicionarAluno(aluno);
    }

    private void mostrarDiario() {
        disciplina.ordenarDiario();
        System.out.println("\nDisciplina: " + disciplina.getCodigo());
        System.out.printf("%-10s %-12s %-8s %-10s %n", "Nome", "Nota", "Faltas",
                "Situacao");
        for (Aluno a : disciplina.getListaAlunos()) {
            System.out.printf("%-10s %-12s %-8s %-10s %n", a.getNome(), a.getNota(),
                    a.getFaltas(), a.getSituacao());
        }
    }
    
}
