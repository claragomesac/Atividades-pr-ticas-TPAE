package com.mycompany.exercicio5;

public class Aluno {
    private int nota;
    private String nome;
    private int faltas;

    public Aluno(String nome,int nota, int faltas) {
        this.nota = nota;
        this.nome = nome;
        this.faltas = faltas;
    }

    public int getNota() {
        return nota;
    }

    public String getNome() {
        return nome;
    }

    public int getFaltas() {
        return faltas;
    }
    
    public String getSituacao(){
        if(nota >= 60 && faltas <= 19){
            return "Aprovado";
        } else {
            return "Reprovado";
        }
    } 
    
}
