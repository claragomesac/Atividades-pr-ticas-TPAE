import java.util.Scanner;
public class Prova {
    private static final int NUM_QUESTOES = 5;

    private Questao[] questoes;
    private Correcao[] correcoes;
    
    public Prova() {
        this.questoes = new Questao[NUM_QUESTOES];
        for (int i = 0; i < NUM_QUESTOES; i++) {
            questoes[i] = new Questao();
        }
    }

    public void aplicar() {
        Scanner scanner = new Scanner(System.in);
        int acertos = 0;

        for (int i = 0; i < NUM_QUESTOES; i++) {
            Questao questao = questoes[i];

            System.out.println("Questão " + questao.getIdQuestao() + ": " + questao.getEnunciado());

            int respostaUsuario = scanner.nextInt();
            boolean respostaCorreta = questao.verificarResposta(respostaUsuario);

            if (respostaCorreta) {
                acertos++;
                System.out.println("Muito bem, você acertou!");
            } else {
                System.out.println("Infelizmente você errou!");
            }
        }

        System.out.println("Você acertou " + acertos + " questões.");
        scanner.close();
    }

    public void gerarRelatorio() {
        System.out.println("Relatório de Correções:");
        System.out.println("Questão\tSituação\tNúmero de Tentativas");
        
        for (Correcao correcao : correcoes) {
            System.out.println(correcao.getNumeroQuestao() + "\t" + correcao.getSituacao() + "\t\t" + correcao.getNumeroTentativas());
        }
    }
}

