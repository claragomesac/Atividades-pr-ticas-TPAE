import java.util.Random;
public class Questao {
    private static int ultimaQuestao = 0;

    private int idQuestao;
    private String enunciado;
    private int gabarito;

    public Questao() {
        Random random = new Random();
        int num1 = random.nextInt(10);
        int num2 = random.nextInt(10);
        this.enunciado = "Quanto é " + num1 + " * " + num2 + "?";
        this.gabarito = num1 * num2;
        
        ultimaQuestao++;
        this.idQuestao = ultimaQuestao;
    }

    public int getIdQuestao() {
        return idQuestao;
    }

    public String getEnunciado() {
        return enunciado;
    }

    public boolean verificarResposta(int resposta) {
        return resposta == gabarito;
    }
}

